package pizzeria;

public class Pizzeria {

}
