package com.company;

public interface Magia {

    void encantar(Personaje p);

    void desencantar(Personaje p);
}
