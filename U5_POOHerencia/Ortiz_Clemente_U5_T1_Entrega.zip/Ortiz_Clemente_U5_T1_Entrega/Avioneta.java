package garaje;

public class Avioneta extends Aereo {
    /**
     * Constructor
     *
     * @param nombre
     * @param numPlazas
     * @param oaci
     */
    public Avioneta(String nombre, int numPlazas, String oaci) {
        super(nombre, numPlazas, oaci);
    }
}
