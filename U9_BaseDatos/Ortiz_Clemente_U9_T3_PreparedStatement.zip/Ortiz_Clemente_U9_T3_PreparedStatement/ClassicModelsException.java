public class ClassicModelsException extends Exception{

    public ClassicModelsException() {
    }

    public ClassicModelsException(String message) {
        super(message);
    }
}
