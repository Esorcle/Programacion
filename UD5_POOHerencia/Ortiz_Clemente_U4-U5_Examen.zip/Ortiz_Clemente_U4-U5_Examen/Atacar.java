package com.company;

public interface Atacar {

    String atacarPersonaje(Personaje p);

}
